import { useState } from 'react'

const MENU_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: '📊' },
  { id: 'tours', label: 'Tours', icon: '🏎️' },
  { id: 'bookings', label: 'Réservations', icon: '📅' },
  { id: 'vehicles', label: 'Véhicules', icon: '🚗' },
  { id: 'customers', label: 'Clients', icon: '👥' },
  { id: 'settings', label: 'Paramètres', icon: '⚙️' }
]

export default function App() {
  const [currentPage, setCurrentPage] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 fixed md:relative z-40 w-64 h-full bg-emerald-900 text-white transition-transform duration-300`}>
        <div className="p-4 border-b border-emerald-700">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🏎️</span>
            <div>
              <h1 className="text-xl font-bold">Trivium Buggy</h1>
              <p className="text-xs text-emerald-300">Gestion des tours</p>
            </div>
          </div>
        </div>
        
        <nav className="p-2">
          {MENU_ITEMS.map(item => (
            <button
              key={item.id}
              onClick={() => { setCurrentPage(item.id); setSidebarOpen(false) }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg mb-1 transition ${currentPage === item.id ? 'bg-emerald-700' : 'hover:bg-emerald-800'}`}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-emerald-700">
          <a href="https://trivium-launcher-production.up.railway.app" className="flex items-center gap-2 text-emerald-300 hover:text-white transition">
            <span>←</span>
            <span>Retour au Launcher</span>
          </a>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-white shadow-sm p-4 flex items-center justify-between">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="md:hidden p-2 rounded-lg hover:bg-gray-100">
            <span className="text-2xl">☰</span>
          </button>
          <h2 className="text-xl font-semibold text-gray-800 capitalize">{currentPage}</h2>
          <div className="text-sm text-gray-500">Trivium Family</div>
        </header>

        {/* Content */}
        <main className="flex-1 p-6 overflow-auto bg-gray-50">
          <div className="bg-white rounded-xl shadow-sm p-8 text-center">
            <span className="text-6xl mb-4 block">🏎️</span>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Bienvenue sur Trivium Buggy</h3>
            <p className="text-gray-500 mb-6">Cette application est en cours de développement.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
              <div className="bg-emerald-50 rounded-lg p-4">
                <div className="text-3xl font-bold text-emerald-600">0</div>
                <div className="text-sm text-gray-600">Tours aujourd'hui</div>
              </div>
              <div className="bg-blue-50 rounded-lg p-4">
                <div className="text-3xl font-bold text-blue-600">0</div>
                <div className="text-sm text-gray-600">Réservations</div>
              </div>
              <div className="bg-orange-50 rounded-lg p-4">
                <div className="text-3xl font-bold text-orange-600">0</div>
                <div className="text-sm text-gray-600">Véhicules</div>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Overlay for mobile */}
      {sidebarOpen && <div onClick={() => setSidebarOpen(false)} className="fixed inset-0 bg-black/50 z-30 md:hidden" />}
    </div>
  )
}
